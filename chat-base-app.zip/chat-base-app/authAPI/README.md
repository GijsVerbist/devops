# Authentication API code
Run this in the serverless environment
