# Basic 3 part chat app for devops assignment

To run application do: `docker-compose up -d` in the main dir of this repo.
