# Frontend html, javascript and css
Serve this code in the nodejs proxy.
